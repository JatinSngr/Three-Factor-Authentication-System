import mongoose from "mongoose";

const userSchema =  new mongoose.Schema({
    name: {type: String, required: true},
    email: {type: String, required: true, unique: true},
    password: {type: String, required: true},
    securityQuestion1: {type: String, required: true},
    securityAnswer1: {type: String, required: true},
    securityQuestion2: {type: String, required: true},
    securityAnswer2: {type: String, required: true},
    securityQuestion3: {type: String, required: true},
    securityAnswer3: {type: String, required: true},
    verifyOtp: {type: String, default: ''},
    verifyOtpExpiresAt: {type: Number, default: 0},
    isAccountVerified: {type: Boolean, default: false},
    resetOtp: {type: String, default: ''},
    resetOtpExpiresAt: {type: Number, default: 0}
})

const userModel = mongoose.models.user || mongoose.model('User', userSchema);
  
export default userModel;