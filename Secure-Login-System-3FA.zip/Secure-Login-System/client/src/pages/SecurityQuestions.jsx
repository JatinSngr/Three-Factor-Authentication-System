import React, { useContext, useState } from 'react'
import { assets } from '../assets/assets'
import { useNavigate } from 'react-router-dom'
import { AppContent } from '../context/AppContext'
import axios from 'axios'
import { toast } from 'react-toastify'

const SecurityQuestions = () => {
    const navigate = useNavigate()
    const {backendUrl, setIsLoggedin, getUserData} = useContext(AppContent)
    
    const [answer1, setAnswer1] = useState('')
    const [answer2, setAnswer2] = useState('')
    const [answer3, setAnswer3] = useState('')

    const onSubmitHandler = async (e) => {
        try {
            e.preventDefault();
            
            axios.defaults.withCredentials = true;
            
            const {data} = await axios.post(backendUrl + '/api/auth/verify-security-questions', {
                userId: localStorage.getItem('userId'),
                answer1,
                answer2,
                answer3
            })

            if(data.success){
                setIsLoggedin(true)
                getUserData()
                localStorage.removeItem('userId')
                navigate('/')
                toast.success("Login successful!")
            }
            else{
                toast.error(data.message)
            }
        } catch (error) {
            toast.error(error.message)
        }
    }

    return (
        <div className='flex items-center justify-center min-h-screen px-6 sm:px-0 bg-gradient-to-br from-blue-200 to-purple-400'>
            <img onClick={()=>navigate('/')} src={assets.logo} alt="" className='absolute left-5 sm:left-20 top-5 w-28 sm:w-32 cursor-pointer' />
            <div className='bg-slate-900 p-10 rounded-lg shadow-lg w-full sm:w-96 text-indigo-300 text-sm'>
                <h2 className='text-3xl font-semibold text-white text-center mb-3'>Security Questions</h2>
                <p className='text-center text-sm mb-6'>Please answer the security questions to complete login</p>
                <form onSubmit={onSubmitHandler}>
                    <div className='mb-4 flex items-center gap-3 w-full px-5 py-2.5 rounded-full bg-[#333A5C]'>
                        <img src={assets.person_icon} alt="" />
                        <input 
                            onChange={e => setAnswer1(e.target.value)} 
                            value={answer1} 
                            className='bg-transparent outline-none' 
                            type="text" 
                            placeholder='Which city were you born?' 
                            required 
                        />
                    </div>
                    <div className='mb-4 flex items-center gap-3 w-full px-5 py-2.5 rounded-full bg-[#333A5C]'>
                        <img src={assets.person_icon} alt="" />
                        <input 
                            onChange={e => setAnswer2(e.target.value)} 
                            value={answer2} 
                            className='bg-transparent outline-none' 
                            type="text" 
                            placeholder='What was the name of your first School?' 
                            required 
                        />
                    </div>
                    <div className='mb-4 flex items-center gap-3 w-full px-5 py-2.5 rounded-full bg-[#333A5C]'>
                        <img src={assets.person_icon} alt="" />
                        <input 
                            onChange={e => setAnswer3(e.target.value)} 
                            value={answer3} 
                            className='bg-transparent outline-none' 
                            type="text" 
                            placeholder='What was your pet name?' 
                            required 
                        />
                    </div>
                    <button className='w-full py-2.5 rounded-full bg-gradient-to-r from-indigo-500 to-indigo-900 text-white font-medium'>Verify</button>
                </form>
            </div>
        </div>
    )
}

export default SecurityQuestions

